"""LSP MATLAB Server for Windows."""

__version__ = "0.1.0"
