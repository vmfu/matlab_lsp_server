"""LSP protocol handlers."""

from . import lifecycle

__all__ = ["lifecycle"]
