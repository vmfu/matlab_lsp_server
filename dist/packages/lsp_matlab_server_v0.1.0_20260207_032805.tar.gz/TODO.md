# TODO.md - Roadmap LSP MATLAB Server for Windows

Статус: ✅ выполнено, 🔄 в работе, ⏳ запланировано, ❌ отменено

---

## Phase 1: Core - Базовая функциональность

### 1.1 Настройка окружения и структуры проекта
- [x] **1.1.1 Анализ задачи**: Изучение текущей структуры проекта, проверка зависимостей, создание базовой директории `src/` с подмодулями `protocol/`, `handlers/`, `parser/`, `analyzer/`, `features/`, `utils/`
- [x] 1.1.2 Создание директорий проекта согласно ARCHITECTURE.md
- [x] 1.1.3 Создание `__init__.py` файлов во всех модулях
- [x] 1.1.4 Настройка `pyproject.toml` для современного управления пакетом (если отсутствует)
- [x] 1.1.5 Тест: Проверка импорта всех модулей `python -c "from src import *"`
- [x] 1.1.6 Отметка выполнения в TODO.md (поставить ✅ в 1.1.1-1.1.5)
- [x] 1.1.7 Коммит: `git commit -m "feat(project): create basic project structure"`
- [x] 1.1.8 Пуш: `git push origin master` (пропущено - нет удаленного репозитория)
- [x] 1.1.9 Суммаризация: Краткое описание выполненной работы и изменений
- [x] 1.1.10 Переход к 1.2 и исполнение TODOs

### 1.2 Реализация менеджера конфигурации
- [x] **1.2.1 Анализ задачи**: Изучение `.matlab-lsprc.json`, проектирование `ConfigManager` с использованием pydantic для валидации конфигурации. **Использовать**: context7 MCP для документации pydantic
- [x] 1.2.2 Создание модели конфигурации в `src/utils/config.py` с pydantic
- [x] 1.2.3 Реализация `ConfigManager` для чтения `.matlab-lsprc.json` и переменных окружения
- [x] 1.2.4 Добавление валидации путей к MATLAB и других настроек
- [x] 1.2.5 Интеграция `ConfigManager` в `server.py`
- [x] 1.2.6 Тест: Проверка чтения конфигурации из файла и env переменных
- [x] 1.2.7 Отметка выполнения в TODO.md (поставить ✅ в 1.2.1-1.2.5)
- [x] 1.2.8 Коммит: `git commit -m "feat(config): implement ConfigManager with pydantic validation"`
- [x] 1.2.9 Пуш: `git push origin master`
- [x] 1.2.10 Суммаризация: Описание реализованного менеджера конфигурации
- [x] 1.2.11 Переход к 1.3 и исполнение TODOs

### 1.3 Реализация системы логирования
- [x] **1.3.1 Анализ задачи**: Изучение требований к логированию для LSP сервера, проектирование `get_logger()` с использованием colorlog. **Использовать**: context7 MCP для документации colorlog и Python logging
- [x] 1.3.2 Создание модуля `src/utils/logging.py` с настройкой цветного логирования
- [x] 1.3.3 Добавление уровней логирования (DEBUG, INFO, WARNING, ERROR)
- [x] 1.3.4 Интеграция логирования в `server.py`
- [x] 1.3.5 Тест: Проверка вывода логов с разными уровнями
- [x] 1.3.6 Отметка выполнения в TODO.md (поставить ✅ в 1.3.1-1.3.4)
- [x] 1.3.7 Коммит: `git commit -m "feat(logging): implement colored logging system"`
- [x] 1.3.8 Пуш: `git push origin master`
- [x] 1.3.9 Суммаризация: Описание системы логирования
- [x] 1.3.10 Переход к 1.4 и исполнение TODOs

### 1.4 Реализация базового класса Handler
- [x] **1.4.1 Анализ задачи**: Изучение паттерна обработчиков LSP методов, проектирование `BaseHandler` для всех LSP хендлеров. **Использовать**: context7 MCP для документации pygls и lsprotocol
- [x] 1.4.2 Создание `src/handlers/base.py` с базовым классом `BaseHandler`
- [x] 1.4.3 Определение абстрактного метода `handle()` для конкретных реализаций
- [x] 1.4.4 Добавление свойств `method_name` для идентификации LSP метода
- [x] 1.4.5 Тест: Создание тестового хендлера и проверка его структуры
- [x] 1.4.6 Отметка выполнения в TODO.md (поставить ✅ в 1.4.1-1.4.4)
- [x] 1.4.7 Коммит: `git commit -m "feat(handlers): implement BaseHandler for LSP methods"`
- [x] 1.4.8 Пуш: `git push origin master`
- [x] 1.4.9 Суммаризация: Описание базового класса хендлеров
- [x] 1.4.10 Переход к 1.5 и исполнение TODOs

### 1.5 Реализация LSP lifecycle хендлеров
- [x] **1.5.1 Анализ задачи**: Изучение LSP спецификации для initialize, shutdown, exit; проектирование lifecycle хендлеров. **Использовать**: context7 MCP для документации LSP specification, z_ai MCP для генерации кода
- [x] 1.5.2 Создание `src/protocol/lifecycle.py` с хендлерами `initialize`, `shutdown`, `exit`
- [x] 1.5.3 Реализация метода `initialize` с объявлением server capabilities
- [x] 1.5.4 Реализация метода `shutdown` для graceful shutdown
- [x] 1.5.5 Реализация метода `exit` для завершения процесса
- [x] 1.5.6 Регистрация lifecycle хендлеров в `MatLSServer`
- [x] 1.5.7 Тест: Проверка инициализации сервера через JSON-RPC сообщения
- [x] 1.5.8 Отметка выполнения в TODO.md (поставить ✅ в 1.5.1-1.5.6)
- [x] 1.5.9 Коммит: `git commit -m "feat(protocol): implement LSP lifecycle handlers (initialize, shutdown, exit)"`
- [x] 1.5.10 Пуш: `git push origin master`
- [x] 1.5.11 Суммаризация: Описание реализации lifecycle хендлеров
- [x] 1.5.12 Переход к 1.6 и исполнение TODOs

### 1.6 Реализация менеджера возможностей (Feature Manager)
- [x] **1.6.1 Анализ задачи**: Изучение LSP capabilities, проектирование `FeatureManager` для регистрации LSP возможностей. **Использовать**: context7 MCP для документации LSP capabilities в lsprotocol
- [x] 1.6.2 Создание `src/features/feature_manager.py` с классом `FeatureManager`
- [x] 1.6.3 Реализация метода `register()` для регистрации хендлеров
- [x] 1.6.4 Реализация метода `get_capabilities()` для получения списка возможностей
- [x] 1.6.5 Интеграция `FeatureManager` в `MatLSServer`
- [x] 1.6.6 Тест: Проверка регистрации хендлеров и получения capabilities
- [x] 1.6.7 Отметка выполнения в TODO.md (поставить ✅ в 1.6.1-1.6.5)
- [x] 1.6.8 Коммит: `git commit -m "feat(features): implement FeatureManager for LSP capabilities"`
- [x] 1.6.9 Пуш: `git push origin master`
- [x] 1.6.10 Суммаризация: Описание менеджера возможностей
- [x] 1.6.11 Переход к 1.7 и исполнение TODOs

### 1.7 Интеграция с mlint - базовая анализаторная система
- [x] **1.7.1 Анализ задачи**: Изучение mlint.exe, его аргументов и формата вывода; проектирование `MlintAnalyzer`. **Использовать**: DuckDuckGo MCP для поиска документации mlint, z_ai MCP для генерации парсера вывода
- [x] 1.7.2 Создание `src/analyzer/base_analyzer.py` с абстрактным `BaseAnalyzer`
- [x] 1.7.3 Создание `src/analyzer/mlint_analyzer.py` с `MlintAnalyzer`
- [x] 1.7.4 Реализация вызова mlint.exe через subprocess
- [x] 1.7.5 Реализация парсинга вывода mlint в структурированный формат
- [x] 1.7.6 Тест: Проверка анализа тестового .m файла с `mlint.bat`
- [x] 1.7.7 Отметка выполнения в TODO.md (поставить ✅ в 1.7.1-1.7.5)
- [x] 1.7.8 Коммит: `git commit -m "feat(analyzer): implement MlintAnalyzer with subprocess integration"`
- [x] 1.7.9 Пуш: `git push origin master`
- [x] 1.7.10 Суммаризация: Описание интеграции с mlint
- [x] 1.7.11 Переход к 1.8 и исполнение TODOs

### 1.8 Реализация диагностики ошибок (textDocument/publishDiagnostics)
- [x] **1.8.1 Анализ задачи**: Изучение LSP диагностических типов, проектирование конвертации mlint вывода в LSP Diagnostic. **Использовать**: context7 MCP для документации lsprotocol Diagnostic types
- [x] 1.8.2 Создание `src/handlers/diagnostics.py` с `DiagnosticsHandler`
- [x] 1.8.3 Реализация хендлера `textDocument/didOpen` для публикации диагностики при открытии файла
- [x] 1.8.4 Реализация хендлера `textDocument/didChange` для обновления диагностики при изменениях
- [x] 1.8.5 Конвертация mlint вывода в LSP Diagnostic с severity levels
- [x] 1.8.6 Интеграция с `MlintAnalyzer` для анализа файлов
- [x] 1.8.7 Тест: Проверка публикации диагностики для `for_tests/test_lsp_detailed.m`
- [x] 1.8.8 Отметка выполнения в TODO.md (поставить ✅ в 1.8.1-1.8.6)
- [x] 1.8.9 Коммит: `git commit -m "feat(diagnostics): implement textDocument/publishDiagnostics"`
- [x] 1.8.10 Пуш: `git push origin master`
- [x] 1.8.11 Суммаризация: Описание реализации диагностики
- [x] 1.8.12 Переход к 1.9 и исполнение TODOs

### 1.9 Реализация синхронизации документов (textDocument/didOpen/didClose/didChange)
- [x] **1.9.1 Анализ задачи**: Изучение LSP document sync, проектирование хранения открытых документов в памяти. **Использовать**: context7 MCP для документации DidOpenTextDocumentParams, DidChangeTextDocumentParams
- [x] 1.9.2 Реализация `textDocument/didOpen` для открытия файла
- [x] 1.9.3 Реализация `textDocument/didClose` для закрытия файла
- [x] 1.9.4 Реализация `textDocument/didChange` для отслеживания изменений
- [x] 1.9.5 Создание `DocumentStore` для хранения содержимого документов
- [x] 1.9.6 Интеграция с diagnostics для триггера анализа при изменениях
- [x] 1.9.7 Тест: Проверка синхронизации при открытии/изменении/закрытии файлов
- [x] 1.9.8 Отметка выполнения в TODO.md (поставить ✅ в 1.9.1-1.9.6)
- [x] 1.9.9 Коммит: `git commit -m "feat(sync): implement textDocument synchronization (didOpen, didClose, didChange)"`
- [x] 1.9.10 Пуш: `git push origin master`
- [x] 1.9.11 Суммаризация: Описание синхронизации документов
- [x] 1.9.12 Переход к 1.10 и исполнение TODOs

### 1.10 Настройка pytest и базовых тестов
- [x] **1.10.1 Анализ задачи**: Изучение pytest, конфигурация для async тестов, планирование тестовой структуры. **Использовать**: context7 MCP для документации pytest и pytest-asyncio
- [x] 1.10.2 Создание `tests/conftest.py` с pytest fixtures
- [x] 1.10.3 Создание `tests/unit/test_config.py` для тестов ConfigManager
- [x] 1.10.4 Создание `tests/unit/test_analyzer.py` для тестов MlintAnalyzer
- [x] 1.10.5 Создание `tests/integration/test_server.py` для тестов инициализации сервера
- [x] 1.10.6 Настройка `.coveragerc` для контроля покрытия кода
- [x] 1.10.7 Тест: Запуск `pytest --cov=src` и проверка покрытия
- [x] 1.10.8 Отметка выполнения в TODO.md (поставить ✅ в 1.10.1-1.10.6)
- [x] 1.10.9 Коммит: `git commit -m "test(pytest): setup pytest framework and basic unit/integration tests"`
- [x] 1.10.10 Пуш: `git push origin master`
- [x] 1.10.11 Суммаризация: Описание настроенного тестового фреймворка
- [x] 1.10.12 Переход к 1.11 и исполнение TODOs

### 1.11 Очистка linting warning в server.py
- [x] **1.11.1 Анализ задачи**: Анализ текущих warning (unused imports, long lines), планировка исправлений
- [x] 1.11.2 Удаление неиспользуемых импортов (`typing.Optional`, `pygls.protocol.LanguageServerProtocol`)
- [x] 1.11.3 Разбивка длинных строк (строки 119, 123) для соответствия PEP 8
- [x] 1.11.4 Запуск `flake8 server.py` для проверки исправлений
- [x] 1.11.5 Тест: Проверка отсутствия warnings в server.py
- [x] 1.11.6 Отметка выполнения в TODO.md (поставить ✅ в 1.11.1-1.11.3)
- [x] 1.11.7 Коммит: `git commit -m "style(server): fix linting warnings (unused imports, long lines)"`
- [x] 1.11.8 Пуш: `git push origin master`
- [x] 1.11.9 Суммаризация: Описание исправлений linting warnings
- [x] 1.11.10 Переход к 2.1 и исполнение TODOs

---

## Phase 2: Essential Features - Основные возможности

### 2.1 Реализация парсера MATLAB (базовый)
- [x] **2.1.1 Анализ задачи**: Изучение MATLAB синтаксиса, проектирование `MatlabParser` для извлечения функций и переменных. **Использовать**: DuckDuckGo MCP для поиска MATLAB syntax docs, z_ai MCP для генерации regex паттернов, z_ai_tools MCP для анализа примеров MATLAB кода
- [x] 2.1.2 Создание `src/parser/models.py` с моделями данных (FunctionInfo, VariableInfo, ParseResult)
- [x] 2.1.3 Создание `src/parser/matlab_parser.py` с `MatlabParser`
- [x] 2.1.4 Реализация извлечения определений функций (function/end)
- [x] 2.1.5 Реализация извлечения объявлений переменных
- [x] 2.1.6 Реализация извлечения комментариев для документации
- [x] 2.1.7 Тест: Парсинг `for_tests/test_matlab_lsp_simple.m` и проверка результатов
- [x] 2.1.8 Отметка выполнения в TODO.md (поставить ✅ в 2.1.1-2.1.6)
- [x] 2.1.9 Коммит: `git commit -m "feat(parser): implement basic MatlabParser (functions, variables, comments)"`
- [x] 2.1.10 Пуш: `git push origin master`
- [x] 2.1.11 Суммаризация: Описание реализованного парсера MATLAB
- [x] 2.1.12 Переход к 2.2 и исполнению TODOs

### 2.2 Расширенный парсер MATLAB (классы и вложенные функции)
- [x] **2.2.1 Анализ задачи**: Изучение MATLAB classdef syntax и nested functions, планировка расширений парсера. **Использовать**: DuckDuckGo MCP для поиска MATLAB OOP syntax, z_ai MCP для генерации парсера классов
- [x] 2.2.2 Реализация извлечения определений классов (classdef/end)
- [x] 2.2.3 Реализация извлечения свойств классов
- [x] 2.2.4 Реализация извлечения методов классов
- [x] 2.2.5 Реализация извлечения вложенных функций
- [x] 2.2.6 Обновление `ParseResult` для поддержки сложных структур
- [x] 2.2.7 Тест: Парсинг .m файла с классами и вложенными функциями
- [x] 2.2.8 Отметка выполнения в TODO.md (поставить ✅ в 2.2.1-2.2.6)
- [x] 2.2.9 Коммит: `git commit -m "feat(parser): add support for classes and nested functions"`
- [x] 2.2.10 Пуш: `git push origin master`
- [x] 2.2.11 Суммаризация: Описание расширенного парсера
- [x] 2.2.12 Переход к 2.3 и исполнению TODOs

### 2.3 Реализация менеджера кэширования
- [x] **2.3.1 Анализ задачи**: Изучение требований к кэшированию (parse cache, analysis cache), проектирование `CacheManager`. **Использовать**: context7 MCP для документации cachetools
- [x] 2.3.2 Создание `src/utils/cache.py` с `CacheManager`
- [x] 2.3.3 Реализация кэша результатов парсинга файлов
- [x] 2.3.4 Реализация кэша результатов mlint анализа
- [x] 2.3.5 Реализация инвалидации кэша при изменении файла
- [x] 2.3.6 Интеграция кэширования в парсер и анализатор
- [x] 2.3.7 Тест: Проверка работы кэша и инвалидации
- [x] 2.3.8 Отметка выполнения в TODO.md (поставить ✅ в 2.3.1-2.3.6)
- [x] 2.3.9 Коммит: `git commit -m "feat(cache): implement CacheManager for parse and analysis results"`
- [x] 2.3.10 Пуш: `git push origin master`
- [x] 2.3.11 Суммаризация: Описание менеджера кэширования
- [x] 2.3.12 Переход к 2.4 и исполнению TODOs

### 2.4 Реализация таблицы символов (Symbol Table)
- [x] **2.4.1 Анализ задачи**: Изучение LSP SymbolInformation, проектирование `SymbolTable` для хранения индекса символов. **Использовать**: context7 MCP для документации lsprotocol SymbolInformation, z_ai MCP для архитектуры Symbol Table
- [x] 2.4.2 Создание `src/utils/symbol_table.py` с `SymbolTable`
- [x] 2.4.3 Реализация добавления символов при открытии/изменении файлов
- [x] 2.4.4 Реализация удаления символов при закрытии файлов
- [x] 2.4.5 Реализация поиска символов по имени и URI
- [x] 2.4.6 Интеграция с `MatlabParser` для пополнения Symbol Table
- [x] 2.4.7 Тест: Индексация символов в тестовых .m файлах
- [x] 2.4.8 Отметка выполнения в TODO.md (поставить ✅ в 2.4.1-2.4.6)
- [x] 2.4.9 Коммит: `git commit -m "feat(symbols): implement SymbolTable for code indexing"`
- [x] 2.4.10 Пуш: `git push origin master`
- [x] 2.4.11 Суммаризация: Описание таблицы символов
- [x] 2.4.12 Переход к 2.5 и исполнению TODOs

### 2.5 Реализация автодополнения кода (textDocument/completion)
- [x] **2.5.1 Анализ задачи**: Изучение LSP completion items, проектирование CompletionHandler. **Использовать**: context7 MCP для документации CompletionItem и CompletionParams, z_ai MCP для генерации логики ранжирования
- [x] 2.5.2 Создание `src/handlers/completion.py` с `CompletionHandler`
- [x] 2.5.3 Реализация получения контекста курсора
- [x] 2.5.4 Реализация фильтрации кандидатов из Symbol Table
- [x] 2.5.5 Реализация ранжирования результатов (по частоте использования, контекстуальность)
- [x] 2.5.6 Добавление built-in MATLAB функций к результатам
- [x] 2.5.7 Регистрация хендлера в `FeatureManager`
- [x] 2.5.8 Тест: Проверка автодополнения в тестовом .m файле
- [x] 2.5.9 Отметка выполнения в TODO.md (поставить ✅ в 2.5.1-2.5.7)
- [x] 2.5.10 Коммит: `git commit -m "feat(completion): implement textDocument/completion with ranking"`
- [x] 2.5.11 Пуш: `git push origin master`
- [x] 2.5.12 Суммаризация: Описание автодополнения
- [x] 2.5.13 Переход к 2.6 и исполнению TODOs

### 2.6 Реализация подсказок при наведении (textDocument/hover)
- [x] **2.6.1 Анализ задачи**: Изучение LSP hover, проектирование HoverHandler для отображения документации. **Использовать**: context7 MCP для документации HoverParams и HoverResult
- [x] 2.6.2 Создание `src/handlers/hover.py` с `HoverHandler`
- [x] 2.6.3 Реализация получения информации о символе под курсором
- [x] 2.6.4 Реализация извлечения документации из комментариев
- [x] 2.6.5 Реализация форматирования вывода с Markdown
- [x] 2.6.6 Регистрация хендлера в `FeatureManager`
- [x] 2.6.7 Тест: Проверка hover для функций и переменных
- [x] 2.6.8 Отметка выполнения в TODO.md (поставить ✅ в 2.6.1-2.6.6)
- [x] 2.6.9 Коммит: `git commit -m "feat(hover): implement textDocument/hover with Markdown documentation"`
- [x] 2.6.10 Пуш: `git push origin master`
- [x] 2.6.11 Суммаризация: Описание реализации hover
- [x] 2.6.12 Переход к 2.7 и исполнению TODOs

### 2.7 Реализация структуры документа (textDocument/documentSymbol)
- [x] **2.7.1 Анализ задачи**: Изучение LSP documentSymbol, проектирование DocumentSymbolHandler. **Использовать**: context7 MCP для документации DocumentSymbol и SymbolKind
- [x] 2.7.2 Создание `src/handlers/document_symbol.py` с `DocumentSymbolHandler`
- [x] 2.7.3 Реализация извлечения иерархии символов из ParseResult
- [x] 2.7.4 Конвертация MATLAB символов в LSP DocumentSymbol с правильными SymbolKind
- [x] 2.7.5 Реализация иерархической структуры (классы > методы, nested functions)
- [x] 2.7.6 Регистрация хендлера в `FeatureManager`
- [x] 2.7.7 Тест: Проверка структуры документа в файле с классами и функциями
- [x] 2.7.8 Отметка выполнения в TODO.md (поставить ✅ в 2.7.1-2.7.6)
- [x] 2.7.9 Коммит: `git commit -m "feat(symbols): implement textDocument/documentSymbol with hierarchy"`
- [x] 2.7.10 Пуш: `git push origin master`
- [x] 2.7.11 Суммаризация: Описание структуры документа
- [x] 2.7.12 Переход к 2.8 и исполнению TODOs

### 2.8 Тестирование Phase 2
- [x] **2.8.1 Анализ задачи**: Проверка всех реализованных функций Phase 2, планировка интеграционных тестов
- [x] 2.8.2 Создание `tests/unit/test_parser.py` с тестами парсера
- [x] 2.8.3 Создание `tests/unit/test_cache.py` с тестами кэша
- [x] 2.8.4 Создание `tests/unit/test_symbol_table.py` с тестами Symbol Table
- [x] 2.8.5 Создание `tests/unit/test_handlers.py` с тестами completion и hover
- [x] 2.8.6 Создание `tests/fixtures/matlab_samples/` с тестовыми .m файлами
- [x] 2.8.7 Запуск `pytest --cov=src` и проверка покрытия (>70%)
- [x] 2.8.8 Отметка выполнения в TODO.md (поставить ✅ в 2.8.1-2.8.6)
- [x] 2.8.9 Коммит: `git commit -m "test(phase2): add comprehensive tests for parser, cache, symbols, handlers"`
- [x] 2.8.10 Пуш: `git push origin master`
- [x] 2.8.11 Суммаризация: Описание результатов тестирования Phase 2
- [x] 2.8.12 Переход к 3.1 и исполнению TODOs

---

## Phase 3: Advanced Features - Расширенные возможности

### 3.1 Реализация перехода к определению (textDocument/definition)
- [x] **3.1.1 Анализ задачи**: Изучение LSP definition, проектирование DefinitionHandler. **Использовать**: context7 MCP для документации Location и DefinitionParams, z_ai MCP для логики поиска определений
- [x] 3.1.2 Создание `src/handlers/definition.py` с `DefinitionHandler`
- [x] 3.1.3 Реализация получения символа под курсором
- [x] 3.1.4 Реализация поиска определения в Symbol Table
- [x] 3.1.5 Реализация кросс-файлового поиска определений
- [x] 3.1.6 Регистрация хендлера в `FeatureManager`
- [x] 3.1.7 Тест: Проверка перехода к определению функции/переменной
- [x] 3.1.8 Отметка выполнения в TODO.md (поставить ✅ в 3.1.1-3.1.6)
- [x] 3.1.9 Коммит: `git commit -m "feat(definition): implement textDocument/definition with cross-file support"`
- [x] 3.1.10 Пуш: `git push origin master`
- [x] 3.1.11 Суммаризация: Описание перехода к определению
- [x] 3.1.12 Переход к 3.2 и исполнению TODOs

### 3.2 Реализация поиска использований (textDocument/references)
- [x] **3.2.1 Анализ задачи**: Изучение LSP references, проектирование ReferencesHandler. **Использовать**: context7 MCP для документации ReferenceParams
- [x] 3.2.2 Создание `src/handlers/references.py` с `ReferencesHandler`
- [x] 3.2.3 Реализация получения символа под курсором
- [x] 3.2.4 Реализация поиска всех использований в Symbol Table
- [x] 3.2.5 Реализация кросс-файлового поиска использований
- [x] 3.2.6 Фильтрация по `includeDeclaration` параметру
- [x] 3.2.7 Регистрация хендлера в `FeatureManager`
- [x] 3.2.8 Тест: Проверка поиска использований функции
- [x] 3.2.9 Отметка выполнения в TODO.md (поставить ✅ в 3.2.1-3.2.7)
- [x] 3.2.10 Коммит: `git commit -m "feat(references): implement textDocument/references with includeDeclaration"`
- [x] 3.2.11 Пуш: `git push origin master`
- [x] 3.2.12 Суммаризация: Описание поиска использований
- [x] 3.2.13 Переход к 3.3 и исполнению TODOs

### 3.3 Реализация быстрых исправлений (textDocument/codeAction)
- [x] **3.3.1 Анализ задачи**: Изучение LSP codeAction, проектирование CodeActionHandler для исправления mlint ошибок. **Использовать**: context7 MCP для документации CodeAction и CodeActionParams, z_ai MCP для логики генерации исправлений
- [x] 3.3.2 Создание `src/handlers/code_action.py` с `CodeActionHandler`
- [x] 3.3.3 Реализация анализа диагностики для определения исправимых ошибок
- [x] 3.3.4 Реализация генерации CodeAction для исправлений
- [x] 3.3.5 Интеграция с mlint для получения исправлений (через `-fix` флаг)
- [x] 3.3.6 Регистрация хендлера в `FeatureManager`
- [x] 3.3.7 Тест: Проверка быстрых исправлений для простых ошибок
- [x] 3.3.8 Отметка выполнения в TODO.md (поставить ✅ в 3.3.1-3.3.6)
- [x] 3.3.9 Коммит: `git commit -m "feat(codeAction): implement textDocument/codeAction with mlint fix suggestions"`
- [x] 3.3.10 Пуш: `git push origin master`
- [x] 3.3.11 Суммаризация: Описание быстрых исправлений
- [x] 3.3.12 Переход к 3.4 и исполнению TODOs

### 3.4 Реализация поиска символов проекта (workspace/symbol)
- [x] **3.4.1 Анализ задачи**: Изучение LSP workspace symbol, проектирование WorkspaceSymbolHandler. **Использовать**: context7 MCP для документации WorkspaceSymbolParams и SymbolInformation
- [x] 3.4.2 Создание `src/handlers/workspace_symbol.py` с `WorkspaceSymbolHandler`
- [x] 3.4.3 Реализация поиска символов по запросу (fuzzy matching)
- [x] 3.4.4 Реализация фильтрации по типу символа (Function, Variable, Class, etc.)
- [x] 3.4.5 Оптимизация поиска с индексацией
- [x] 3.4.6 Регистрация хендлера в `FeatureManager`
- [x] 3.4.7 Тест: Проверка поиска символов по имени во всем проекте
- [x] 3.4.8 Отметка выполнения в TODO.md (поставить ✅ в 3.4.1-3.4.6)
- [x] 3.4.9 Коммит: `git commit -m "feat(workspace): implement workspace/symbol with fuzzy search"`
- [x] 3.4.10 Пуш: `git push origin master`
- [x] 3.4.11 Суммаризация: Описание поиска символов проекта
- [x] 3.4.12 Переход к 3.5 и исполнению TODOs

### 3.5 Тестирование Phase 3
- [x] **3.5.1 Анализ задачи**: Проверка всех функций Phase 3, планировка end-to-end тестов
- [x] 3.5.2 Создание `tests/integration/test_definition.py` для тестов перехода к определению
- [x] 3.5.3 Создание `tests/integration/test_references.py` для тестов поиска использований
- [x] 3.5.4 Создание `tests/integration/test_code_action.py` для тестов быстрых исправлений
- [x] 3.5.5 Создание `tests/integration/test_workspace_symbol.py` для тестов поиска символов
- [x] 3.5.6 Запуск всех тестов: `pytest --cov=src` (>80% покрытие)
- [x] 3.5.7 Отметка выполнения в TODO.md (поставить ✅ в 3.5.1-3.5.5)
- [x] 3.5.8 Коммит: `git commit -m "test(phase3): add integration tests for definition, references, codeAction, workspace/symbol"`
- [x] 3.5.9 Пуш: `git push origin master`
- [x] 3.5.10 Суммаризация: Описание результатов тестирования Phase 3
- [x] 3.5.11 Переход к 4.1 и исполнению TODOs

---

## Phase 4: Polish - Финализация и оптимизация

### 4.1 Реализация форматирования кода (textDocument/formatting)
- [x] **4.1.1 Анализ задачи**: Изучение MATLAB code style, проектирование FormattingHandler. **Использовать**: DuckDuckGo MCP для поиска MATLAB code style guidelines, z_ai MCP для генерации форматтера
- [x] 4.1.2 Создание `src/handlers/formatting.py` с `FormattingHandler`
- [x] 4.1.3 Реализация отступов (config.indentSize)
- [x] 4.1.4 Реализация выравнивания end ключевых слов
- [x] 4.1.5 Реализация форматирования операторов и пробелов
- [x] 4.1.6 Регистрация хендлера в `FeatureManager`
- [x] 4.1.7 Тест: Проверка форматирования .m файла
- [x] 4.1.8 Отметка выполнения в TODO.md (поставить ✅ в 4.1.1-4.1.6)
- [x] 4.1.9 Коммит: `git commit -m "feat(formatting): implement textDocument/formatting with configurable style"`
- [x] 4.1.10 Пуш: `git push origin master`
- [x] 4.1.11 Суммаризация: Описание форматирования кода
- [x] 4.1.12 Переход к 4.2 и исполнению TODOs

### 4.2 Оптимизация производительности
- [x] **4.2.1 Анализ задачи**: Профилирование сервера, поиск узких мест, планировка оптимизаций. **Использовать**: DuckDuckGo MCP для поиска Python profiling best practices, z_ai MCP для предложений по оптимизации
- [x] 4.2.2 Профилирование `python -m cProfile server.py`
- [x] 4.2.3 Оптимизация кэширования (LRU cache для Symbol Table)
- [x] 4.2.4 Оптимизация парсинга (инкрементальный парсинг)
- [x] 4.2.5 Дебаунсинг событий didChange для уменьшения количества анализов
- [x] 4.2.6 Асинхронный вызов mlint для неблокирующего анализа
- [x] 4.2.7 Тест: Проверка производительности на большом проекте
- [x] 4.2.8 Отметка выполнения в TODO.md (поставить ✅ в 4.2.1-4.2.6)
- [x] 4.2.9 Коммит: `git commit -m "perf(optimization): add caching, debouncing, async mlint calls"`
- [x] 4.2.10 Пуш: `git push origin master`
- [x] 4.2.11 Суммаризация: Описание оптимизаций производительности
- [x] 4.2.12 Переход к 4.3 и исполнению TODOs

### 4.3 Настройка pre-commit хуков
- [x] **4.3.1 Анализ задачи**: Изучение pre-commit, планировка хуков для автоматизации quality checks. **Использовать**: context7 MCP для документации pre-commit
- [x] 4.3.2 Создание `.pre-commit-config.yaml` с хуками
- [x] 4.3.3 Добавление хука black для форматирования
- [x] 4.3.4 Добавление хука isort для сортировки импортов
- [x] 4.3.5 Добавление хука flake8 для линтинга
- [x] 4.3.6 Добавление хука mypy для type checking
- [x] 4.3.7 Тест: Установка хуков `pre-commit install` и проверка коммита
- [x] 4.3.8 Отметка выполнения в TODO.md (поставить ✅ в 4.3.1-4.3.6)
- [x] 4.3.9 Коммит: `git commit -m "ci(pre-commit): add pre-commit hooks for code quality"`
- [x] 4.3.10 Пуш: `git push origin master`
- [x] 4.3.11 Суммаризация: Описание pre-commit хуков
- [x] 4.3.12 Переход к 4.4 и исполнению TODOs

### 4.4 Создание CHANGELOG.md
- [x] **4.4.1 Анализ задачи**: Изучение всех коммитов, планировка структуры CHANGELOG.md
- [x] 4.4.2 Создание `CHANGELOG.md` с версией 0.1.0
- [x] 4.4.3 Документирование Phase 1 изменений
- [x] 4.4.4 Документирование Phase 2 изменений
- [x] 4.4.5 Документирование Phase 3 изменений
- [x] 4.4.6 Документирование Phase 4 изменений
- [x] 4.4.7 Добавление секции "Breaking Changes" (если есть)
- [x] 4.4.8 Отметка выполнения в TODO.md (поставить ✅ в 4.4.1-4.4.7)
- [x] 4.4.9 Коммит: `git commit -m "docs(changelog): add CHANGELOG.md for version 0.1.0"`
- [x] 4.4.10 Пуш: `git push origin master`
- [x] 4.4.11 Суммаризация: Описание CHANGELOG.md
- [x] 4.4.12 Переход к 4.5 и исполнению TODOs

### 4.5 Финальное тестирование и документация
- [x] **4.5.1 Анализ задачи**: Комплексное тестирование, проверка документации
- [x] 4.5.2 Запуск полного тестового набора: `pytest --cov=src` (>90% покрытие)
- [x] 4.5.3 Запуск линтеров: `black --check`, `flake8`, `mypy`
- [x] 4.5.4 Обновление README.md с актуальной информацией о возможностях
- [x] 4.5.5 Обновление ARCHITECTURE.md с итоговой структурой
- [x] 4.5.6 Обновление DEVELOPMENT.md с актуальными командами
- [x] 4.5.7 Проверка INTEGRATION.md с примерами конфигураций
- [x] 4.5.8 Ручное тестирование в TUI Crush с реальными .m файлами
- [x] 4.5.9 Отметка выполнения в TODO.md (поставить ✅ в 4.5.1-4.5.7)
- [x] 4.5.10 Коммит: `git commit -m "docs: update documentation and final testing for v0.1.0"`
- [x] 4.5.11 Пуш: `git push origin master`
- [x] 4.5.12 Суммаризация: Описание финального состояния проекта
- [x] 4.5.13 Переход к 4.6 и исполнению TODOs

### 4.6 Подготовка релиза v0.1.0
- [x] **4.6.1 Анализ задачи**: Подготовка тега релиза, проверка всех артефактов
- [x] 4.6.2 Проверка версии в `server.py` (__version__ = "0.1.0")
- [x] 4.6.3 Создание git тега: `git tag -a v0.1.0 -m "Release v0.1.0 - Initial LSP MATLAB Server"`
- [x] 4.6.4 Пуш тега: `git push origin v0.1.0`
- [x] 4.6.5 Создание GitHub Release с описанием возможностей
- [x] 4.6.6 (Опционально) Подготовка пакета для PyPI: `python -m build`
- [x] 4.6.7 (Опционально) Публикация в PyPI: `twine upload dist/*`
- [x] 4.6.8 Отметка выполнения в TODO.md (поставить ✅ в 4.6.1-4.6.7)
- [x] 4.6.9 Коммит: `git commit -m "chore(release): prepare v0.1.0 release"`
- [x] 4.6.10 Пуш: `git push origin master`
- [x] 4.6.11 Суммаризация: Описание завершения разработки v0.1.0
- [x] 4.6.12 Переход к планировке будущих версий

---

## Бонус задачи

### 5.1 Реализация tree-sitter-matlab парсера
- [x] **5.1.1 Анализ задачи**: Изучение tree-sitter и tree-sitter-matlab, интеграция как альтернативного парсера. **Использовать**: DuckDuckGo MCP для поиска tree-sitter MATLAB grammar, z_ai MCP для интеграции
- [x] 5.1.2 Установка tree-sitter и tree-sitter-matlab
- [x] 5.1.3 Создание адаптера для tree-sitter парсера
- [x] 5.1.4 Реализация фоллбэка на regex парсер если tree-sitter недоступен
- [x] 5.1.5 Сравнение производительности regex vs tree-sitter
- [x] 5.1.6 Отметка выполнения в TODO.md
- [x] 5.1.7 Коммит: `git commit -m "feat(parser): add tree-sitter-matlab as alternative parser"`
- [x] 5.1.8 Пуш: `git push origin master`
- [x] 5.1.9 Суммаризация: Описание tree-sitter интеграции

### 5.2 Поддержка macOS и Linux
- [x] **5.2.1 Анализ задачи**: Изучение отличий в путях и вызове mlint на разных ОС
- [x] 5.2.2 Обновление скриптов для кроссплатформенности
- [x] 5.2.3 Тестирование на Linux (через WSL или контейнер)
- [x] 5.2.4 Тестирование на macOS
- [x] 5.2.5 Обновление документации с информацией о поддержке ОС
- [x] 5.2.6 Отметка выполнения в TODO.md
- [x] 5.2.7 Коммит: `git commit -m "feat(cross-platform): add macOS and Linux support"`
- [x] 5.2.8 Пуш: `git push origin master`
- [x] 5.2.9 Суммаризация: Описание кроссплатформенной поддержки

### 5.3 Создание альтернативного анализатора без MATLAB
- [x] **5.3.1 Анализ задачи**: Изучение альтернатив mlint (например, Octave linter), планировка независимого анализатора. **Использовать**: DuckDuckGo MCP для поиска open source MATLAB linters, z_ai MCP для реализации
- [x] 5.3.2 Создание `src/analyzer/standalone_analyzer.py`
- [x] 5.3.3 Реализация базовых правил (undefined variables, syntax errors)
- [x] 5.3.4 Реализация расширенных правил (unused variables, etc.)
- [x] 5.3.5 Фоллбэк на standalone анализатор если mlint недоступен
- [x] 5.3.6 Отметка выполнения в TODO.md
- [x] 5.3.7 Коммит: `git commit -m "feat(analyzer): add standalone analyzer for environments without MATLAB"`
- [x] 5.3.8 Пуш: `git push origin master`
- [x] 5.3.9 Суммаризация: Описание автономного анализатора

---

## Примечания для агента

### Порядок выполнения:
1. Всегда начинайте с подпункта "Анализ задачи" (X.X.1)
2. После выполнения всех подпунктов задачи, переходите к следующей номерной задаче
3. Используйте MCP инструменты как указано в подпункте "Анализ задачи"
4. После каждой задачи обязательно: тест → отметка в TODO.md → коммит → пуш → суммаризация → переход

### MCP инструменты по типу задач:

| Тип задачи | MCP инструмент | Назначение |
|-----------|---------------|-----------|
| Изучение библиотек | context7 MCP | Документация pygls, lsprotocol, pytest, colorlog, cachetools |
| Генерация кода | z_ai MCP | Генерация хендлеров, парсеров, логики ранжирования |
| Поиск информации | DuckDuckGo MCP | MATLAB syntax, code style, mlint docs, best practices |
| Анализ изображений | z_ai_tools MCP | Анализ диаграмм архитектуры, скриншотов кода |
| Работа с файлами | Filesystem MCP | Анализ структуры проекта, поиск файлов |

### Пример workflow для задачи 1.2 (Config Manager):
```
1. Выполнить 1.2.1: Анализ задачи → использовать context7 MCP для pydantic docs
2. Выполнить 1.2.2-1.2.5: Реализация
3. Выполнить 1.2.6: Тестирование
4. Выполнить 1.2.7: Отметить ✅ в 1.2.1-1.2.5 в TODO.md
5. Выполнить 1.2.8: git commit
6. Выполнить 1.2.9: git push
7. Выполнить 1.2.10: Суммаризация
8. Выполнить 1.2.11: Переход к 1.3 и исполнение TODOs (через todos tool)
```

### Легенда статусов:
- ✅ - выполнено (выполняется агентом после завершения задачи)
- 🔄 - в работе (текущая задача)
- ⏳ - запланировано (ожидает выполнения)
- ❌ - отменено (если применимо)
### COMPLETED - All TODO tasks completed ✅
### COMPLETED - All TODO tasks completed ✅
